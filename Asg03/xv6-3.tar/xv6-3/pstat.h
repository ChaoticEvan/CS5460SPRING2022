#ifndef _PSTAT_H_
#define _PSTAT_H_

#include "param.h"

struct pstatentry {
    int inuse;
    int tickets;
    int pid;
    int ticks;    
};

struct pstat {
    struct pstatentry proc[NPROC];
};

#endif