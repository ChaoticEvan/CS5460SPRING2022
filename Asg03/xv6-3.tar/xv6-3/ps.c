#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"

int
main(int argc, char *argv[])
{  
  struct pstat *procs = malloc(sizeof(*procs));
  printf(1, "PID TICKETS TICKS\n");
  int statusCode = getpinfo(procs);
  printf(2, "%d\n", statusCode);
  if(statusCode < 0) {
    printf(1, "ps: failed to get info on processes\n");
    free(procs);
    exit();
  }

  
  int i;
  printf(1, "test\n");
  for(i = 0; i < 10; ++i) {
    printf(2, "%d\n", procs->proc[0].tickets);
  }
  
  free(procs);
  exit();
}
