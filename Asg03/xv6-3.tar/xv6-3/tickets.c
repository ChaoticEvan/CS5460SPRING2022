#include "pstat.h"
#include "types.h"
#include "stat.h"
#include "user.h"


int
main(int argc, char *argv[])
{  
  if(argc != 3) {
    printf(1, "ERROR: tickets does not have the correct amount of arguments\n");
    exit();
  }

  int numTickets = (int) argv[1];  
  char* args = {argv[2]};

  if(exec(argv[2], &args) < 0) {
      printf(1, "ERROR: could not execute process");
      exit();
  }

  settickets(numTickets);

  exit();
}
